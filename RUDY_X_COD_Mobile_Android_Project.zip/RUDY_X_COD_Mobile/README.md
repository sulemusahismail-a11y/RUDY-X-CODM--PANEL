# RUDY X COD Mobile Tactical Assistant

A standalone Android Studio project with a VOLTEX-inspired dark/purple interface.

## Included
- Aim-training timer and practice instructions
- Recoil-control practice routine
- Sensitivity note-entry screen
- Weapon practice profiles (including Kilo 141)
- Device/display information screen
- HUD and training notes screen

## Important limitation
This is a companion training app. It does not inject into COD Mobile, automate aiming/firing, change game memory, unlock CP, or bypass anti-cheat. It cannot read or modify the game's private settings.

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish (Android Gradle Plugin 8.7.3; compile SDK 35).
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Find the debug APK under `app/build/outputs/apk/debug/app-debug.apk`.

Minimum Android version: Android 6.0 (API 23).
