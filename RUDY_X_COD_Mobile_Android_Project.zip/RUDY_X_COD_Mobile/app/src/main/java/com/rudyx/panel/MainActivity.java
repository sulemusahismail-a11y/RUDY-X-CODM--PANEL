package com.rudyx.panel;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import android.text.InputType;
import java.util.Locale;

public class MainActivity extends Activity {
    final int BG=Color.rgb(10,10,16), CARD=Color.rgb(25,22,36), PURPLE=Color.rgb(164,92,255), WHITE=Color.WHITE, MUTED=Color.rgb(185,176,201);
    LinearLayout root, body;
    TextView timerText;
    Handler handler = new Handler();
    long endAt=0; boolean running=false;
    Runnable ticker = new Runnable(){ public void run(){
        if(!running) return;
        long left=Math.max(0,endAt-System.currentTimeMillis());
        if(timerText!=null) timerText.setText(String.format(Locale.US,"%02d:%02d",left/60000,(left/1000)%60));
        if(left==0){running=false; if(timerText!=null) timerText.setText("00:00  •  COMPLETE");}
        else handler.postDelayed(this,250);
    }};
    public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG); showHome();}
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density);}
    TextView text(String s,int size,int color,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(null,Typeface.BOLD); return t;}
    LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    void showHome(){
        root=vertical(); root.setBackgroundColor(BG);
        ScrollView scroll=new ScrollView(this); body=vertical(); body.setPadding(dp(18),dp(18),dp(18),dp(28)); scroll.addView(body); root.addView(scroll);
        TextView brand=text("RUDY X",27,PURPLE,true); body.addView(brand);
        body.addView(text("TACTICAL ASSISTANT  /  COD MOBILE",11,MUTED,true));
        LinearLayout status=vertical(); status.setPadding(dp(14),dp(12),dp(14),dp(12)); status.setBackgroundColor(CARD);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=dp(18);body.addView(status,sp);
        status.addView(text("●  TRAINING MODE READY",13,Color.rgb(130,255,180),true));
        status.addView(text("Standalone companion • No game injection or anti-cheat bypass",11,MUTED,false));
        section("QUICK TOOLS");
        addCard("AIM TRAINING","Timed focus and target-tracking practice", "Start 60-second drill",()->startDrill(60));
        addCard("RECOIL PRACTICE","Structured vertical and horizontal recoil-control routine","Open practice routine",()->showRecoil());
        addCard("SENSITIVITY OPTIMIZER","Record and compare your own sensitivity settings","Tune sensitivity",()->showSensitivity());
        addCard("WEAPON LOADOUTS","Save a training profile for your Kilo 141 or another weapon","Manage loadouts",()->showLoadouts());
        addCard("DEVICE PERFORMANCE","Check refresh rate, memory class and display details","View device info",()->showDevice());
        addCard("HUD & TRAINING PROFILE","Keep a personal layout and practice notes","Edit profile",()->showProfile());
        TextView foot=text("RUDY X  •  VERSION 1.0\\nPractice tools only. Settings do not modify COD Mobile.",10,MUTED,false);
        LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,-2);fp.topMargin=dp(18);body.addView(foot,fp);
        setContentView(root);
    }
    void section(String s){TextView t=text(s,12,MUTED,true);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(22);p.bottomMargin=dp(8);body.addView(t,p);}
    void addCard(String title,String desc,String action,Runnable r){
        LinearLayout c=vertical();c.setPadding(dp(14),dp(14),dp(14),dp(14));c.setBackgroundColor(CARD);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(10);body.addView(c,p);
        c.addView(text(title,16,WHITE,true));TextView d=text(desc,12,MUTED,false);LinearLayout.LayoutParams dp1=new LinearLayout.LayoutParams(-1,-2);dp1.topMargin=dp(5);c.addView(d,dp1);
        Button b=button(action);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.topMargin=dp(10);c.addView(b,bp);b.setOnClickListener(v->r.run());
    }
    Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(PURPLE));return b;}
    void page(String title,String subtitle){
        root=vertical();root.setBackgroundColor(BG);root.setPadding(dp(18),dp(18),dp(18),dp(20));
        Button back=button("←  Back to dashboard");root.addView(back);back.setOnClickListener(v->showHome());
        TextView h=text(title,23,WHITE,true);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=dp(20);root.addView(h,hp);
        TextView sub=text(subtitle,12,MUTED,false);LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,-2);pp.topMargin=dp(6);pp.bottomMargin=dp(16);root.addView(sub,pp);
        ScrollView sc=new ScrollView(this);body=vertical();sc.addView(body);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
    }
    void startDrill(int seconds){
        page("AIM TRAINING","Follow a target with your eyes and keep your thumb movement smooth. This timer does not interact with the game.");
        timerText=text(String.format(Locale.US,"%02d:%02d",seconds/60,seconds%60),42,PURPLE,true);timerText.setGravity(Gravity.CENTER);body.addView(timerText);
        Button start=button("Start / restart drill");body.addView(start);start.setOnClickListener(v->{running=true;endAt=System.currentTimeMillis()+seconds*1000L;handler.removeCallbacks(ticker);handler.post(ticker);});
        Button stop=button("Stop");body.addView(stop);stop.setOnClickListener(v->{running=false;handler.removeCallbacks(ticker);timerText.setText("PAUSED");});
        note("60-second drill: track a moving target for 20 seconds, switch direction for 20 seconds, then repeat while keeping movement controlled.");
    }
    void note(String s){TextView t=text(s,14,WHITE,false);t.setPadding(dp(12),dp(14),dp(12),dp(14));t.setBackgroundColor(CARD);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(12);body.addView(t,p);}
    void showRecoil(){page("RECOIL PRACTICE","A repeatable practice routine; no automated recoil control.");note("1. Equip your chosen weapon in the training range.\\n\\n2. Fire a short burst at a wall from a fixed distance.\\n\\n3. Observe the pattern, then repeat while gently compensating with your thumb.\\n\\n4. Practise 5-, 10- and 20-round bursts.\\n\\n5. Change one sensitivity setting at a time and compare results.");}
    void showSensitivity(){
        page("SENSITIVITY OPTIMIZER","Save your own values and adjust gradually. These are personal notes, not universal recommended values.");
        String[] labels={"Standard sensitivity","ADS sensitivity","Tactical scope","3x scope","4x scope","Sniper scope"};
        for(String label:labels){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(label+" (enter value)");e.setHintTextColor(MUTED);e.setTextColor(WHITE);e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(PURPLE));body.addView(e);}
        note("Tip: test camera movement first, then ADS tracking. Keep a note of each change so you can revert if your aim becomes inconsistent.");
    }
    void showLoadouts(){page("WEAPON LOADOUTS","Create a practice profile for your current in-game build.");String[] weapons={"Kilo 141","M13","AK-47","QQ9","Custom weapon"};for(String w:weapons){Button b=button("Select "+w);body.addView(b);b.setOnClickListener(v->new AlertDialog.Builder(this).setTitle(w+" profile").setMessage("Use this profile to record your in-game attachments and recoil notes.").setPositiveButton("OK",null).show());}}
    void showDevice(){page("DEVICE PERFORMANCE","Read-only Android device information.");android.util.DisplayMetrics m=new android.util.DisplayMetrics();getWindowManager().getDefaultDisplay().getMetrics(m);note("Display resolution: "+m.widthPixels+" × "+m.heightPixels+"\\nDensity: "+m.densityDpi+" dpi\\nRefresh rate: "+getWindowManager().getDefaultDisplay().getRefreshRate()+" Hz\\nAndroid: "+Build.VERSION.RELEASE+"\\nDevice: "+Build.MANUFACTURER+" "+Build.MODEL+"\\n\\nFor smoother play, close unused apps and use stable graphics settings supported by your device.");}
    void showProfile(){page("HUD & TRAINING PROFILE","Keep your personal layout notes.");EditText e=new EditText(this);e.setHint("Write your HUD layout, finger setup and practice goals…");e.setHintTextColor(MUTED);e.setTextColor(WHITE);e.setMinLines(5);e.setGravity(Gravity.TOP);e.setBackgroundColor(CARD);body.addView(e);Button save=button("Save notes on this screen");body.addView(save);save.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("Profile notes are ready. Copy them into your own notes app to keep a backup.").setPositiveButton("OK",null).show());note("Suggested profile fields: finger layout, gyro on/off, fire button position, ADS button position, preferred weapon and practice date.");}
}